//Global
var url = 'phpEditorFile.php';
var url_download = 'phpDownloadFile.php';
var STRING_MARK = "_";
var SLICE_STRING = '>';
var STEPS_PERFORMED = 0;
var parsing = [false,false,false,false]; // Check if the functions already start to update --> BackUpCourse, BackUpSections, getResources, backUpSettings

//edCrumble
var edCrumbleObj;
var topic = ['Sense Topic', 'Programa General', 'Educació', 'Humanitat i arts', 'Ciències Socials, empresarials i jurídiques', 'Ciències', 'Enginyeria, fabricació i construcció', 'Agricultura', 'Salut i benestar', 'Serveis'];//['Unselected topic','General programmes', 'Education', ' Humanities and arts', 'Social sciences, business and law', 'Science', ' Engineering, manufacturing and construction', 'Agriculture', 'Health and welfare', 'Services'];
var educationalLevel = ['No seleccionat', 'Educació infantil', 'Educació secundaria inferior', 'Educació secundaria superior', 'Educació postsecundària no terciària', 'Educació terciària de cicle curt', 'Licenciatura o equivalent', 'Máster o equivalent', 'Doctorat o equivalent'];//['Unselected educational level','Early childhood Education', 'Primary education', 'Lower secondary education', 'Upper secondary education', 'Post-secondary non-tertiary education', 'Short-cycle tertiary education', 'Bachelor or equivalent', 'Master or equivalent', 'Doctoral or equivalent'];
var typeOfTasks = ['Neutral', 'Recordar', 'Entender', 'Aplicar', 'Analizar', 'Evaluar', 'Crear'];
var studentRoleTasks = ['Individual', 'En grups de: ', 'Tots junts'];
var gradeTasks = ['No evaluable', 'Auto evaluable', 'Ho evalua el professor'];
var moodleID = "8"

//Moodle
var dirMoodleActivities = "MoodleActivities/"
/*var activities = {
    forum: "forum_base",
    label: "label_base",
    url : "url_base"
}
*/
var timeStartParse;
var backUpFile;
var nameDirMoodle;
var nameDirResources;

var sections = []; //[DD - mouth]
var yearStartSections;
var dirSections = []; // [dir]
var sequenceActivities; // [[ID_activity1,ID_activity2...]]  

var activitiesArray = []; // [{info, type}]

var resourcesArray = [];

var settings; //[[level, activityName]]

var startID = 5;
var moduleID = 25;
var contextID = 66;

var startStringMoodle = ['&lt;p','&lt;h4', ' dir="ltr" style="text-align: left;"&gt;']; // normalSize, bigSize, continue of the line
var endStringMoodle = "\r\n";
var enterStringMoodle = '&amp;nbsp;&lt;/p&gt;&lt;p dir="ltr" style="text-align: left;"&gt;';


//moodle_backup.xml
var backUpParamsEdit = {
    //General
    nameDir : '<name></name>', //.zip
    backupDate : '<backup_date></backup_date>',
    nameL : '<original_course_fullname></original_course_fullname>',
    nameS : '<original_course_shortname></original_course_shortname>',
    dateStart : '<original_course_startdate></original_course_startdate>',
    dateEnd : '<original_course_enddate></original_course_enddate>',

    //Directory
    directory : '<directory></directory>',

    //Activity
    Act_StartWrite : '</activities>', // Point to add info, put again the line in the last pos of the string
    Act_Encapsulate : '<activity></activity>',
    Act_moduleId : '<moduleid></moduleid>',
    Act_section : '<sectionid></sectionid>',
    Act_moduleName : '<modulename></modulename>',
    Act_title : '<title></title>',
    //directory

    //Sections
    Sec_StartWrite : '</sections>', // Point to add info, put again the line in the last pos of the string
    Sec_Encapsulate : '<section></section>',
    Sec_section : '<sectionid></sectionid>',
    Sec_title : '<title></title>',
    //directory

    //Course
    Course_StartWrite : '</course>', // Point to add info, put again the line in the last pos of the string
    Course_Id : '<courseid></courseid>',
    Course_title : '<title></title>',
    //directory

    //Setting
    Setting_StartWrite : '</settings>',
    Setting_Encapsulate : '<setting></setting>',
    level : '<level></level>',
    section : '<section></section>',
    activity : '<activity></activity>',
    nameSitting : '<name></name>',
    value : '<value></value>'

}
//course/course.xml
var courseParamsEdit = {
    nameS : '<shortname></shortname>',
    nameL : '<fullname></fullname>',
    startDate : '<startdate></startdate>',
    endDate : '<enddate></enddate>',
    timeCreated : '<timecreated></timecreated>',
    timeEdit : '<timemodified></timemodified>'
}

//sections
var sectionsParamsEdit = {
    ID : '<section id=>',
    number : '<number></number>',
    Sname : '<name></name>',
    secuencia_activitats : '<sequence></sequence>',
    timeEdit : '<timemodified></timemodified>'
}


// Activities
var moduleParamsEdit = {
    //module.xml
    id : '<module id=>', // id="" version="2021052500"
    section : '<sectionid></sectionid>',
    left : '<indent></indent>',
    visible : '<visible></visible>' // 1= visible, 0 = invisible
}

var labelParamsEdit = {
    //label.xml
    header : '<activity id=>', // id="" moduleid="" modulename="label" contextid=""
    id : '<label id=>',
    name : '<name></name>',
    description : '<intro></intro>',
    timeEdit : '<timemodified></timemodified>',
}

var urlParamsEdit = {
    //url.xml
    header : '<activity id=>', // id="" moduleid="" modulename="label" contextid=""
    id : '<url id=>',
    name : '<name></name>',
    description : '<intro></intro>',
    url : '<externalurl></externalurl>',
    timeEdit : '<timemodified></timemodified>',
}

var resourceParamsEdit = {
    header : '<activity id=>', // id="" moduleid="" modulename="label" contextid=""
    id : '<resource id=>',
    name : '<name></name>',
    description : '<intro></intro>',
    timeEdit : '<timemodified></timemodified>',
}

// Resources
var fileParams = {
    //files.xml 2 <files> for the same resource
    StartWrite : '</files>',
    id : '<file id=>', 

    hash1 : '<contenthash>9da33c86122f05d3424504e1b2f654426984b155</contenthash>',
    hash2 : '<contenthash>da39a3ee5e6b4b0d3255bfef95601890afd80709</contenthash>',

    contextId : '<contextid></contextid>',
    info1 : ' <component>mod_resource</component>\r\n<filearea>content</filearea>\r\n<itemid>0</itemid>\r\n<filepath>/</filepath>',
    name : '<filename></filename>', // Default .

    info2 : '<userid>2</userid>\r\n<filesize>18</filesize>\r\n<mimetype>text/plain</mimetype>\r\n<status>0</status>',
    defaultInfo2 : '<userid>2</userid>\r\n<filesize>0</filesize>\r\n<mimetype>$@NULL@$</mimetype>\r\n<status>0</status>',

    timeCreated : '<timecreated></timecreated>',
    timeModified : '<timemodified></timemodified>',
    source : '<source></source>', // Default $@NULL@$

    info3 : '<author>unknow</author>\r\n<license>unknown</license>\r\n<sortorder>1</sortorder>\r\n<repositorytype>$@NULL@$</repositorytype>\r\n<repositoryid>$@NULL@$</repositoryid>\r\n<reference>$@NULL@$</reference>\r\n</file>',
    defaultInfo3 : '<author>$@NULL@$</author>\r\n<license>$@NULL@$</license>\r\n<sortorder>0</sortorder>\r\n<repositorytype>$@NULL@$</repositorytype>\r\n<repositoryid>$@NULL@$</repositoryid>\r\n<reference>$@NULL@$</reference>\r\n</file>'
}
// Functions

function formStringJsontoMoodle(myStr){
    return myStr.replace(/(?:\r\n|\r|\n)/g, enterStringMoodle);
}

function addStringtoString(baseS, appendS, sliceS = SLICE_STRING){ // Base string, what put and character for index
    if(baseS.slice(baseS.indexOf(sliceS)+1,baseS.length) != "")
        return baseS.slice(0,baseS.indexOf(sliceS)+1) + appendS + baseS.slice(baseS.indexOf(sliceS)+1,baseS.length) + endStringMoodle;
    else
        return baseS.slice(0,baseS.indexOf(sliceS)) + appendS + baseS.slice(baseS.indexOf(sliceS),baseS.length) + endStringMoodle;
}

function fromDatetoInt(dateS){
    var date = new Date (dateS);
    return date.getTime();
}

Date.prototype.getWeek = function (dowOffset) {
    /*getWeek() was developed by Nick Baicoianu at MeanFreePath: http://www.meanfreepath.com */
    
        dowOffset = typeof(dowOffset) == 'int' ? dowOffset : 0; //default dowOffset to zero
        var newYear = new Date(this.getFullYear(),0,1);
        var day = newYear.getDay() - dowOffset; //the day of week the year begins on
        day = (day >= 0 ? day : day + 7);
        var daynum = Math.floor((this.getTime() - newYear.getTime() - 
        (this.getTimezoneOffset()-newYear.getTimezoneOffset())*60000)/86400000) + 1;
        var weeknum;
        //if the year starts before the middle of a week
        if(day < 4) {
            weeknum = Math.floor((daynum+day-1)/7) + 1;
            if(weeknum > 52) {
                nYear = new Date(this.getFullYear() + 1,0,1);
                nday = nYear.getDay() - dowOffset;
                nday = nday >= 0 ? nday : nday + 7;
                /*if the next year starts before the middle of
                  the week, it is week #1 of that year*/
                weeknum = nday < 4 ? 1 : 53;
            }
        }
        else {
            weeknum = Math.floor((daynum+day-1)/7);
        }
        return weeknum;
};

function updateFile(file, param, content, encapsulate = ""){
    // 1 param
    if(!Array.isArray(param) && !Array.isArray(content)){
        content = addStringtoString(param, content);
        return ModifyParam(file, param, content);
    }
    // this never will haven
    else if(!Array.isArray(param) || !Array.isArray(content)){
        alert("ERROR EN EL PROGRAMA, PONTE EN CONTACTO CON EL PROVEEDOR");
    }
    else{
        if((param.length - 1) != content.length) // The last param not put anything
            alert("ERROR EN EL PROGRAMA, PONTE EN CONTACTO CON EL PROVEEDOR");

            var final_content = "";
            var iterations = param.length;
            for(var i = 0; i < iterations; i++){
                if(i == (iterations-1)){
                    if(encapsulate != "")
                        final_content = addStringtoString(encapsulate, final_content);
                        
                    final_content += param[i];
                    final_content += endStringMoodle;
                }
                else{
                    final_content += addStringtoString(param[i], content[i]);
                }
            }

            return ModifyParam(file, param[param.length -1], final_content);
    }
}

function modifySameFile(file, paramsToEdit, contexts, encapsulate = ""){
    // 1 param
    if(!Array.isArray(paramsToEdit) && !Array.isArray(contexts)){
        $.when(updateFile(file, paramsToEdit, contexts, encapsulate)).done(function(){
            return true;
        });
    }
    // this never will haven
    else if(!Array.isArray(paramsToEdit) || !Array.isArray(contexts)){
        alert("ERROR EN EL PROGRAMA, PONTE EN CONTACTO CON EL PROVEEDOR");
    }
    else if(paramsToEdit.length != 0 && contexts.length != 0){
        $.when(updateFile(file, paramsToEdit[0], contexts[0], encapsulate)).done(function(){
            paramsToEdit.shift();
            contexts.shift();
            modifySameFile(file, paramsToEdit, contexts, encapsulate);
        });
    }
    else{
        return true;
    }
}

//Variables Without Project
var month_Str = new Array();
month_Str[0] = "Gener";
month_Str[1] = "Febrer";
month_Str[2] = "Març";
month_Str[3] = "Abril";
month_Str[4] = "Maig";
month_Str[5] = "Juny";
month_Str[6] = "Juliol";
month_Str[7] = "Agost";
month_Str[8] = "Setembre";
month_Str[9] = "Octubre";
month_Str[10] = "Novembre";
month_Str[11] = "Desembre";
/*
month_Str[0] = "Enero";
month_Str[1] = "Febrero";
month_Str[2] = "Marzo";
month_Str[3] = "Abril";
month_Str[4] = "Mayo";
month_Str[5] = "Junio";
month_Str[6] = "Julio";
month_Str[7] = "Agosto";
month_Str[8] = "Septiembre";
month_Str[9] = "Octubre";
month_Str[10] = "Noviembre";
month_Str[11] = "Diciembre";*/