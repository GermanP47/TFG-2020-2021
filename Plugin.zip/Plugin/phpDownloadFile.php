<?php
    if(isset($_GET['filename'])){
        //Read the url
        $url = 'ParseMoodle/'.$_GET['filename'];
        
        //Clear the cache
        clearstatcache();
        
        //Check the file path exists or not
        //echo($url);
        if(file_exists($url)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="'.basename($url).'"');
            header('Content-Length: ' . filesize($url));
            header('Pragma: public');

            flush();

            readfile($url, true);

            //Delete the file after download completion or cancellation
            ignore_user_abort(true);
            unlink($url);

        }
    }
?>