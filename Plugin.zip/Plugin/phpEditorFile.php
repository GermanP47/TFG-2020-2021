<?php

    header('Content-Type: text/html; charset=UTF-8');
    //Utils
    function replace_a_line($data) {
        $parameter = isset($_POST['parameter']) ? $_POST['parameter'] : '';
        $content = isset($_POST['content']) ? $_POST['content'] : '';

        if (stristr($data, $parameter)) {
            return $content;
        }
            return $data;
    }

    class editFile {
        private $filename;
        public $root = 'ParseMoodle/';
        public $rootNewActivity = 'MoodleActivities/';
    
        public function __construct() {

            if($_SERVER['REQUEST_METHOD'] === 'POST'){
                $action = isset($_POST['action']) ? $_POST['action'] : false;
                $this->filename = isset($_POST['filename']) ? $_POST['filename'] : false;
            }
            else if($_SERVER['REQUEST_METHOD'] === 'GET'){
                $action = isset($_GET['action']) ? $_GET['action'] : false;
                $this->filename = isset($_GET['filename']) ? $_GET['filename'] : false;
            }

            if ((!$action)) return;
            switch ($action) {
                case 'newMoodle' :
                    $this->newMoodleParse(); break;
                case 'newActivity':
                    $this->createActivity(); break;
                case 'newResource' :
                    $this->createResource(); break;
                case 'change' : 
                    $this->change(); break;
                case 'Zip' : 
                    $this->zipFolder(); break;
                default :
                    return;
                    break;
            }
            return true;
        }

        // Create new directory
        public function newDirectory($dir){
            mkdir($dir); 
        }
        // Delete directory and the files inside
        public function deleteDirectory($dir){
            $baseFiles = scandir($dir);
            foreach ($baseFiles as $key => $value){
    
                if (!in_array($value,array(".",".."))){
    
                    if (is_dir($dir . '/' . $value)){
                        $this->deleteDirectory($dir . '/' . $value);
                    }
                    else{
                        unlink($dir . '/' . $value);
                    }
                }
            }
            rmdir($dir);
        }
        //Copy files from folder X to folder Y
        public function copyFiles($old, $new){
    
            $baseFiles = scandir($old);
    
            foreach ($baseFiles as $key => $value){
    
                if (!in_array($value,array(".",".."))){
    
                    if (is_dir($old . '/' . $value)){
                        $this->newDirectory($new . '/' . $value);
                        $this->copyFiles($old . '/' . $value, $new . '/' . $value);
                    }
    
                    else{
                        copy($old . '/' . $value , $new . '/' . $value);
                    }
                }
            }
        }

        // Create new Moodle BackUp
        private function newMoodleParse(){

            $newDir = $this->root.$this->filename;
            $this->newDirectory($newDir);

            $resources = isset($_POST['resources']) ? $_POST['resources'] : '';
            $dirResources = $this->root.$resources;
            $this->newDirectory($dirResources);

            $baseDir = 'MoodleBase';
            $this->copyFiles($baseDir, $newDir);
        }

        //Create new directory
        private function createActivity(){
            $activity = isset($_POST['nameActivity']) ? $_POST['nameActivity'] : '';
            $typeActivity;
            switch($activity){
                case 'section' :{
                    $typeActivity ='section_base';
                    break;
                }
                case 'label' : {
                    $typeActivity ='label_base';
                    break;
                }
                case 'url' : {
                    $typeActivity ='url_base';
                    break;
                }
                case 'resource' : {
                    $typeActivity ='resource_base';
                    break;
                }
                default :
                    return;
                    break;
            }
            $newDir = $this->root.$this->filename;
            $this->newDirectory($newDir);

            $baseDir = $this->rootNewActivity.$typeActivity;
            $this->copyFiles($baseDir, $newDir);
        }

        private function createResource(){
            $dir = $this->root.$this->filename;
            $content = isset($_POST['content']) ? $_POST['content'] : '';
            $info = base64_decode($content);
            
            $fr = fopen($dir, "w");
            fwrite($fr, $info);
            fclose($fr);
        }

        // Change File Values
        private function change() {
            $data = file($this->root.$this->filename); // reads an array of lines
            $data = array_map('replace_a_line',$data);
            file_put_contents($this->root.$this->filename, implode('', $data));
        }

        // Zip Moodle BackUp || Resources Course
        private function zipFolder(){
            $newDir = realpath($this->root.$this->filename);

            $zip = new ZipArchive();
            $zip->open($newDir.'.zip', ZipArchive::CREATE | ZipArchive::OVERWRITE);
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($newDir),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            
            foreach ($files as $name => $file)
            {
                // Skip directories (they would be added automatically)
                if (!$file->isDir())
                {
                    // Get real and relative path for current file
                    $filePath = $file->getRealPath();
                    $relativePath = substr($filePath, strlen($newDir) + 1);
            
                    // Add current file to archive
                    $zip->addFile($filePath, $relativePath);
                }
            }
            
            // Zip archive will be created only after closing object
            $zip->close();

            // Delete Folder
            $this->deleteDirectory($newDir);
        }
    }

    $editorfile = new editFile();
?>