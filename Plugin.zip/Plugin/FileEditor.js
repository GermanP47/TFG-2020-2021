/* Load edCrumble File */
const fileSelector = document.getElementById('file-selector');
fileSelector.addEventListener('change', (event) => {
    const fileList = event.target.files;
	if(fileList.length == 0)
		return;

	fr = new FileReader();
	fr.readAsText(fileList[0]);

	fr.onloadend = function() {
		try{
			edCrumbleObj = JSON.parse(fr.result);
			sendEdcrumbleInfo();
		} catch(e){
			alert("No has seleccionat un arxiu valid" + e);
		}		
	}

});

fileSelector.addEventListener('click', (event) => {
	edCrumbleObj = "undefined";
	fileSelector.value = "";
})

/* Download Files */
function downloadZips(){
    DownloadFileMoodle();
    DownloadFileResources();
}


//Functions to Modify Files
function backUpSettings(iterator){
    if(typeof(settings) == "undefined" || settings.length == 0 || settings.length == iterator){
        STEPS_PERFORMED++;
        return;
    }

    if(typeof(settings[iterator][0]) == "undefined"){
        return backUpSettings(++iterator);
    }

    var level =  settings[iterator][0];
    var activityName =  settings[iterator][1];

    var includeSettings = "_included";
    var userInfoSettings = "_userinfo";

    var paramArray;
    var contextArray1 = [level, activityName, activityName + includeSettings, "1"];
    var contextArray2 = [level, activityName, activityName + userInfoSettings, "1"];

    switch(level){
        case 'section' :{
            paramArray = [backUpParamsEdit["level"], backUpParamsEdit["section"], backUpParamsEdit["nameSitting"], backUpParamsEdit["value"], backUpParamsEdit["Setting_StartWrite"]];
            break;
        }
        case 'activity' : {
            paramArray = [backUpParamsEdit["level"], backUpParamsEdit["activity"], backUpParamsEdit["nameSitting"], backUpParamsEdit["value"], backUpParamsEdit["Setting_StartWrite"]];
            break;
        }
        default:{
            return;
        }
    }
    $.when(modifySameFile(backUpFile, [paramArray, paramArray], [contextArray1, contextArray2], backUpParamsEdit["Setting_Encapsulate"])).done(function(){
        return backUpSettings(++iterator);
    });
}

function putFilesIntoMoodle(F_id, F_contextId, F_name){ // add info to files.xml, root
    var file = nameDirMoodle + '/files.xml';
    var paramArray1 = [fileParams['id'], fileParams['hash1'], fileParams['contextId'], fileParams['info1'], fileParams['name'],fileParams['info2'], fileParams['timeCreated'], fileParams['timeModified'], fileParams['source'], fileParams['info3'], fileParams['StartWrite']]
    var paramArray2 = [fileParams['id'], fileParams['hash2'], fileParams['contextId'], fileParams['info1'], fileParams['name'],fileParams['defaultInfo2'], fileParams['timeCreated'], fileParams['timeModified'], fileParams['source'], fileParams['defaultInfo3'], fileParams['StartWrite']]

    var context1 = ["\"" + F_id.toString() + "\"", "", F_contextId, "", F_name, "", timeStartParse.toString(), timeStartParse.toString(), F_name, ""];
    var context2 = ["\"" + F_id.toString() + "\"", "", F_contextId, "", '.', "", timeStartParse.toString(), timeStartParse.toString(), '$@NULL@$', ""];
    modifySameFile(file, [paramArray1, paramArray2], [context1, context2]);
}

function modifyActivity(activityName, file, params){

    var paramsToModify;
    var contextToAdd;

    switch(activityName){
        case 'section':{ // [localID, iterator.toString(), name]
            file = file + "/section.xml";
            paramsToModify = [sectionsParamsEdit['ID'],sectionsParamsEdit['number'],sectionsParamsEdit['Sname'],sectionsParamsEdit['timeEdit']];
            contextToAdd = ["\"" + params[0].toString() + "\"", params[1], params[2], timeStartParse.toString()];
            modifySameFile(file, paramsToModify, contextToAdd);
            break;
        }
        case 'label': { //[header, activity["id"], title, activity["nameActivity"], activity["moduleId"], activity["section"], type]
            var indent;
            var visible;
            var moodleString;
            switch(params[6]){
                case 'activity' :{
                    indent = 0;
                    visible = 1;
                    moodleString = startStringMoodle[1] + startStringMoodle[2];
                    break;
                }
                case 'task' :{
                    indent = 3;
                    visible = 0;
                    moodleString = startStringMoodle[0] + startStringMoodle[2];
                    break;
                }
                default : {
                    return;
                }
            }

            var fileL = file + "/label.xml"
            paramsToModify = [labelParamsEdit['header'],labelParamsEdit['id'],labelParamsEdit['name'],labelParamsEdit['description'], labelParamsEdit["timeEdit"]];
            contextToAdd = [params[0],"\"" + params[1].toString() + "\"",params[2], moodleString + params[3],timeStartParse.toString()];
            modifySameFile(fileL, paramsToModify, contextToAdd);

            fileM = file + "/module.xml";
            paramsToModify = [moduleParamsEdit['id'],moduleParamsEdit['section'],moduleParamsEdit['left'],moduleParamsEdit['visible']];
            contextToAdd = ["\"" + params[4] + "\" version=\"2021052500\"", params[5], indent.toString(), visible.toString()];
            modifySameFile(fileM, paramsToModify, contextToAdd);
            break;
        }
        case 'url':{ // [header, activity["id"], title, description, activity["context"],activity["moduleId"],activity["section"], activity["visible"],type]
            var moodleString = startStringMoodle[0] + startStringMoodle[2];

            var fileL = file + "/url.xml"
            paramsToModify = [urlParamsEdit['header'],urlParamsEdit['id'],urlParamsEdit['name'],urlParamsEdit['description'], urlParamsEdit['url'], urlParamsEdit["timeEdit"]];
            contextToAdd = [params[0],"\"" + params[1].toString() + "\"",params[2], moodleString + params[3],params[4],timeStartParse.toString()];
            modifySameFile(fileL, paramsToModify, contextToAdd);

            fileM = file + "/module.xml";
            paramsToModify = [moduleParamsEdit['id'],moduleParamsEdit['section'],moduleParamsEdit['visible']];
            contextToAdd = ["\"" + params[5] + "\" version=\"2021052500\"", params[6], params[7].toString()];
            modifySameFile(fileM, paramsToModify, contextToAdd);
            break;
        }

        case 'resource' : { // [header, activity["id"], title, description,activity["moduleId"],activity["section"], activity["visible"],type];
            var moodleString = startStringMoodle[0] + startStringMoodle[2];

            var fileL = file + "/resource.xml"
            paramsToModify = [resourceParamsEdit['header'],resourceParamsEdit['id'],resourceParamsEdit['name'],resourceParamsEdit['description'], resourceParamsEdit["timeEdit"]];
            contextToAdd = [params[0],"\"" + params[1].toString() + "\"",params[2], moodleString + params[3],timeStartParse.toString()];
            modifySameFile(fileL, paramsToModify, contextToAdd);

            fileM = file + "/module.xml";
            paramsToModify = [moduleParamsEdit['id'],moduleParamsEdit['section'],moduleParamsEdit['visible']];
            contextToAdd = ["\"" + params[4] + "\" version=\"2021052500\"", params[5], params[6].toString()];
            modifySameFile(fileM, paramsToModify, contextToAdd);
            break;
        }
        default :{
            return;
        }
    }
}

function descriptionCourse(){
        var DescriptionOftheCourse  = '<intro>&lt;p dir="ltr" style="text-align: left;"&gt;&lt;/p&gt;&lt;p dir="ltr"&gt;&lt;strong&gt;Descripció: &lt;/strong&gt;&amp;nbsp;';
        DescriptionOftheCourse += enterStringMoodle + formStringJsontoMoodle(edCrumbleObj["description"]);
    
        DescriptionOftheCourse += '&lt;/p&gt;&lt;p dir="ltr"&gt;&lt;strong&gt;Avaluació: &lt;/strong&gt;&amp;nbsp;'
        DescriptionOftheCourse += enterStringMoodle + formStringJsontoMoodle(edCrumbleObj["evaluation"]);
    
        DescriptionOftheCourse += '&lt;br&gt;&lt;/p&gt;&lt;p dir="ltr"&gt;&lt;strong&gt;Experiència: &lt;/strong&gt;&amp;nbsp;'
        DescriptionOftheCourse += formStringJsontoMoodle(edCrumbleObj["experience"]);
    
        DescriptionOftheCourse += '&lt;br&gt;&lt;/p&gt;&lt;p dir="ltr"&gt;&lt;strong&gt;Objectius: &lt;/strong&gt;&amp;nbsp;'
        var iterations = edCrumbleObj["objectivesList"].length;
        for(let objective of edCrumbleObj["objectivesList"]){
            if(objective == "")
                continue;
            DescriptionOftheCourse += objective;
            if(!--iterations)
                DescriptionOftheCourse += '.';
            else
                DescriptionOftheCourse += ', ';
        }
    
        DescriptionOftheCourse += '&lt;br&gt;&lt;/p&gt;&lt;p dir="ltr"&gt;&lt;strong&gt;Nombre d’Alumnes: &lt;/strong&gt;&amp;nbsp;'
        DescriptionOftheCourse += edCrumbleObj["students"];
    
        DescriptionOftheCourse += '&lt;/p&gt;&lt;p dir="ltr"&gt;&lt;strong&gt;Topic: &lt;/strong&gt;'
        if(edCrumbleObj["topic"] == "")
            DescriptionOftheCourse += topic[0];
        else
            DescriptionOftheCourse += topic[parseInt(edCrumbleObj["topic"])];
    
        DescriptionOftheCourse += '&lt;/p&gt;&lt;p dir="ltr"&gt;&lt;strong&gt;Nivell educacional: &lt;/strong&gt;'
        if(edCrumbleObj["educationalLevel"] == "")
            DescriptionOftheCourse += educationalLevel[0];
        else
            DescriptionOftheCourse += educationalLevel[parseInt(edCrumbleObj["educationalLevel"])];
    
        DescriptionOftheCourse += '</intro>';
        DescriptionOftheCourse += endStringMoodle;
    
        $.when(ModifyParam(nameDirMoodle+'/activities/label_20/label.xml', labelParamsEdit['description'], DescriptionOftheCourse)).done(function(){ //Default file
            STEPS_PERFORMED++;
            return;
        }); 
}

function BackUpBase(){ //Default file
    var paramsToModify = [backUpParamsEdit["nameDir"], backUpParamsEdit["nameL"], backUpParamsEdit["nameS"], backUpParamsEdit["backupDate"], backUpParamsEdit["dateStart"], backUpParamsEdit["dateEnd"]];
    var contextToAdd = [nameDirMoodle + ".zip", edCrumbleObj["designTitle"], edCrumbleObj['designTitle'], timeStartParse.toString(), fromDatetoInt(edCrumbleObj['startDate']).toString(), fromDatetoInt(edCrumbleObj['endDate']).toString()];

    $.when(modifySameFile(backUpFile, paramsToModify, contextToAdd)).done(function(){
        STEPS_PERFORMED++;
        return;
    });
}

function BackUpCourse(){
    var defaultID = "18";
    var name = edCrumbleObj["designTitle"];
    var defaultDirectory = "course";

    var paramArray = [backUpParamsEdit["Course_Id"], backUpParamsEdit["Course_title"], backUpParamsEdit["directory"], backUpParamsEdit["Course_StartWrite"]];
    var contextArray = [defaultID, name, defaultDirectory];

    $.when(updateFile(backUpFile, paramArray, contextArray)).done(function(){
        STEPS_PERFORMED++;
        return;
    });
}

function BackUpSections(mySections, iterator){
    var name = mySections[iterator-1] + " - " + (parseInt(mySections[iterator].toString().substring(0, mySections[iterator].toString().indexOf(' '))) -1).toString() + mySections[iterator].toString().substring(mySections[iterator].toString().indexOf(' '), mySections[iterator].toString().length);
    var localID = startID;
    var directory = "sections/section_" + localID.toString();

    var paramArray = [backUpParamsEdit["Sec_section"], backUpParamsEdit["Sec_title"], backUpParamsEdit["directory"], backUpParamsEdit["Sec_StartWrite"]];
    var contextArray = [localID, name, directory];

    //Create dir of the activity and modify it
    $.when(createActivity('section', nameDirMoodle + "/" + directory)).done(function(){
        modifyActivity('section', nameDirMoodle + "/" + directory, [localID, iterator.toString(), name]);
    });


    $.when(updateFile(backUpFile, paramArray, contextArray, backUpParamsEdit['Sec_Encapsulate'])).done(function(){
        dirSections.push([directory]);
        if(typeof(settings) == "undefined"){
            settings = [["section", "section_" + localID.toString()]];
            sequenceActivities = [[]];
        }
        else{
            settings.splice(settings.length,0,["section", "section_" + localID.toString()]);
            sequenceActivities.splice(settings.length,0,[]);
        }
        startID = startID +1;
        if(mySections.length > iterator +1)
            BackUpSections(mySections, iterator+1);
        else{
            STEPS_PERFORMED++;
            return;
        }
    });
}

function updateSequenceSections(iterator){
    if(iterator == dirSections.length){
        STEPS_PERFORMED++;
        return;
    }
    file = nameDirMoodle + "/" + dirSections[iterator] + "/section.xml";
    context = "";
    for(i in sequenceActivities[iterator]){
        context += sequenceActivities[iterator][i].toString();
        if((parseInt(i)+1) != sequenceActivities[iterator].length)
            context += ",";
    } 
    $.when(updateFile(file, sectionsParamsEdit["secuencia_activitats"], context)).done(function(){
        updateSequenceSections(++iterator);
    });
}

function BackupActivities(iterator){
    if(iterator == activitiesArray.length){
        STEPS_PERFORMED++;
        return;
    }
    var activity = activitiesArray[iterator];
    var type = activity["type"];
    var directory;
    var title;
    var description;

    var typeFile; // label, url
    var params;

    switch(type){
        case 'activity': {
            directory = "activities/label_" + activity["moduleId"];
            title = formStringJsontoMoodle(activity["nameActivity"].substring(0,20));
            typeFile = 'label';
            description = formStringJsontoMoodle(activity["nameActivity"]) + " - " + activity["schedule"];// + " - Dies: " + activity["date"];
            break;
        }
        case 'task' : {
            directory = "activities/label_" + activity["moduleId"];
            title = activity["Tcontent"].substring(0,20);
            typeFile = 'label';
            description = "Duració de la tasca: " + activity["Ttime"] + " min - Tipus de tasca: " + activity["Ttype"] + " - " + activity["TstudentRole"] + " - " + activity["Tgrade"];
            if(activity["Tobjectives"].length != 0){
                description +=  enterStringMoodle + "Objectius de la tasca: "
                for(i in activity["Tobjectives"]){
                    description += edCrumbleObj["objectivesList"][i] + ", ";
                }
            }
            description +=  enterStringMoodle + "Descripció de la tasca: " + formStringJsontoMoodle(activity["Tcontent"]);
            break;
        }
        case 'url': { 
            activity = activity['info'];
            directory = "activities/url_" + activity["moduleId"];
            title = activity["nameResource"];
            typeFile = 'url';
            description = formStringJsontoMoodle(activity["description"]);
            break;
        }
        case 'resource' : {
            activity = activity['info'];
            directory = "activities/resource_" + activity["moduleId"];
            title = activity["nameResource"];
            typeFile = 'resource';
            description = formStringJsontoMoodle(activity["description"]);
            break;
        }
        default : {
            return;
        }
    }

    var paramArray = [backUpParamsEdit["Act_moduleId"], backUpParamsEdit["Act_section"], backUpParamsEdit["Act_moduleName"], backUpParamsEdit["Act_title"], backUpParamsEdit["directory"], backUpParamsEdit["Act_StartWrite"]];
    var contextArray = [activity["moduleId"], activity["section"], typeFile, title ,directory];
    var header = "\"" + activity["id"] + "\" moduleid=\"" + activity["moduleId"] + "\" modulename=\"" + typeFile + "\" contextid=\"" + activity["contextId"] + "\"";

    switch(typeFile){
        case 'label':{
            params = [header, activity["id"], title, description, activity["moduleId"],activity["section"], type];
            break;
        }
        case 'url' :{
            params = [header, activity["id"], title, description, activity["context"],activity["moduleId"],activity["section"], activity["visible"],type]
            break;
        }
        case 'resource' :{
            params = [header, activity["id"], title, description,activity["moduleId"],activity["section"], activity["visible"],type];
            break;
        }
        default : {
            return;
        }
    }

    //Create dir of the activity and modify it
    $.when(createActivity(typeFile, nameDirMoodle + "/" + directory)).done(function(){
        modifyActivity(typeFile, nameDirMoodle + "/" + directory, params);
    });

    $.when(updateFile(backUpFile, paramArray, contextArray, backUpParamsEdit['Act_Encapsulate'])).done(function(){
        settings.splice(settings.length,0,["activity", typeFile + "_" + activity["moduleId"]]);
        if(typeFile == 'resource'){
            createResources(title + activity["format"], activity["content"]);
            $.when(putFilesIntoMoodle(activity["id"], activity["contextId"], "prueba online.txt")).done(function(){
                BackupActivities(++iterator);
            });
        }
        else{
            BackupActivities(++iterator);
        }
    });
}

function paramsCourse(){
    var courseFile = nameDirMoodle + '/course/course.xml';
    var paramsToModify = [courseParamsEdit["nameS"], courseParamsEdit["nameL"], courseParamsEdit["startDate"], courseParamsEdit["endDate"], courseParamsEdit["timeCreated"], courseParamsEdit["timeEdit"]];
    var contextToAdd = [edCrumbleObj["designTitle"], edCrumbleObj["designTitle"], fromDatetoInt(edCrumbleObj['startDate']), fromDatetoInt(edCrumbleObj['endDate']), timeStartParse.toString(), timeStartParse.toString()];

    $.when(modifySameFile(courseFile, paramsToModify, contextToAdd)).done(function(){
        STEPS_PERFORMED++;
        return;
    });
}

function getActivities(listActivities, iterator){
    if(iterator == listActivities.length){
        BackupActivities(0);
        return;
    }
    var activity = listActivities[iterator];

    var nameActivity = activity["title"];
    var schedule = "";
    var date;
    var type = 'activity';

    var dateS = new Date(activity["start"]).getDate();
    var dateF = new Date(activity["end"]).getDate();
    if(dateS == dateF)
        date = dateS.toString();
    else
        date = dateS.toString() + " - " + dateF.toString();

    if(activity["group"] == 1)
        schedule = "Horari Escolar";
    else
        schedule = "Horari Extraescolar";

    
    var activitySection = (new Date(activity["start"]).getWeek() - new Date(edCrumbleObj["startDate"]).getWeek());
    if(activitySection > sequenceActivities.length -1)
        activitySection = sequenceActivities.length -1;
    sequenceActivities[activitySection].push(moduleID);

    if(activitiesArray.length == 0){
        activitiesArray = [{
            type : type,
            nameActivity: nameActivity,
            schedule : schedule,
            date : date,
            id : startID.toString(),
            moduleId : moduleID.toString(),
            contextId : contextID.toString(),
            section : (activitySection + 5).toString()
        }]
    }
    else{
        activitiesArray.push({
            type : type,
            nameActivity: nameActivity,
            schedule : schedule,
            date : date,
            id : startID.toString(),
            moduleId : moduleID.toString(),
            contextId : contextID.toString(),
            section : (activitySection + 5).toString()
        })
    }

    startID++;
    moduleID++;
    contextID++;

    for (tasks of activity["tasks"]){
        var studentRole = studentRoleTasks[tasks["student_role"] - 1];
        if(studentRole == studentRoleTasks[1])
            studentRole = studentRole + tasks["students_group"];

        activitiesArray.push({
            type : 'task',
            Ttype : typeOfTasks[tasks["type"] - 1],
            Tcontent : tasks["description"],
            TstudentRole : studentRole,
            Ttime : tasks["min"],
            Tgrade : gradeTasks[tasks["graded"] - 1],
            Tobjectives : activity["objectives"],
            id : startID.toString(),
            moduleId : moduleID.toString(),
            contextId : contextID.toString(),
            section : (activitySection + 5).toString()
        });

        sequenceActivities[activitySection].push(moduleID);
        startID++;
        moduleID++;
        contextID++;

        //Put resources
        for (index of tasks["resources"]){
            if(typeof(resourcesArray[index -1]) == "undefined" || resourcesArray[index -1]['type'] == 'no_valid')
                continue;
            var resource = resourcesArray[index -1];
            resource.section = (activitySection + 5).toString();
            sequenceActivities[activitySection].push(parseInt(resource['moduleId']));
            activitiesArray.push({
                type : resource['type'],
                info : resource
            })
        }
    }

    getActivities(listActivities, ++iterator);
}

function getSections(date){ // Take the date and every 7 days new section
    var day =  date.getDate();
    var month = date.getMonth();
    var year = date.getFullYear();

    sections.push([day.toString() + " " + month_Str[month]]);

    for(var iterator = 0; iterator < 7; iterator++){
        if(day > 27){
            var localdate = new Date(year, month, day+1);
            var localDay = localdate.getDate();
            if(localDay != 1){
                day = day + 1;
            }
            else if(localDay == 1){
                month += 1;
                day = 1;
            }
            else if(month < 12){
                month = month + 1;
                day = 1;
            }
            else{
                year = year + 1
                month = 0;
                day = 1;
            }
        }
        else{
            day = day + 1;
        }
    }

    var endDate = new Date(edCrumbleObj['endDate']);
    var dayEnd =  endDate.getDate();
    var monthEnd = endDate.getMonth();
    var yearEnd = endDate.getFullYear();
    if(year == yearEnd && month == monthEnd && Math.abs(day - dayEnd) < 7){
        sections.push([dayEnd.toString() + " " + month_Str[month]]);
    }
    else{
        getSections(new Date(year, month, day));
    }

}

function getResources(listResources, iterator){ // 'description', 'title', 'url', 'target_student'
    if(typeof(listResources[iterator]) == "undefined"){
        if(Object.keys(edCrumbleObj["resourcesList"]).length == resourcesArray.length){
            //Take activities from edCrumbleObj
            getActivities(edCrumbleObj['itemsList'], 0);
            return;
        }
        else{
            return getResources(listResources, ++iterator);
        }
    }
    
    var resource = listResources[iterator];
    var nameResource = resource['title'];
    if(nameResource == "")
        nameResource = 'Recurso_' + startID.toString();

    var descriptionResource = resource['description'];
    var visible = 0;
    var type = "";
    var content = "";
    var format = "";
    if(resource['target_student'])
        visible = 1;
    else
        visible = 0;
    
    if(resource['url'] != ""){
        type = 'url';
        content = resource['url'];
    }
    else if (resource.hasOwnProperty('content') && resource['content']['data'] != ""){
        type = 'resource';
        var index = resource['content']['data'].indexOf(';') +1;
        content = resource['content']['data'].substring(index, resource['content']['data'].length);
        index = content.indexOf(',') + 1;
        content = content.substring(index, content.length);

        index = resource['content']['filename'].indexOf('.');
        format = resource['content']['filename'].substring(index, resource['content']['filename'].length);
    }
    else{
        type = 'no_valid';
    }

    //Check if is a Moodle resource
    /*
    if(resource['medium_type '] != moodleID){
        type = 'no_valid';
    }*/

    if(resourcesArray.length == 0){
        if(type == 'no_valid'){
            resourcesArray = [{type : type}];
            return getResources(listResources, ++iterator);
        }
        else
            resourcesArray = [{
                type : type,
                nameResource: nameResource,
                edCrumbleId : iterator,
                description : descriptionResource,
                visible : visible,
                content : content,
                format : format,

                id : startID.toString(),
                moduleId : moduleID.toString(),
                contextId : contextID.toString()
            }];
    }
    else{
        if(type == 'no_valid'){
            resourcesArray.push({type : type});
            return getResources(listResources, ++iterator);
        }
        else
            resourcesArray.push({
                type : type,
                nameResource: nameResource,
                edCrumbleId : iterator,
                description : descriptionResource,
                visible : visible,
                content : content,
                format : format,

                id : startID.toString(),
                moduleId : moduleID.toString(),
                contextId : contextID.toString()
            });
    }

    startID++;
    moduleID++;
    contextID++;

    getResources(listResources, ++iterator);
}

function finishModifyFiles(){
    if(STEPS_PERFORMED == 8){
        $.when(ZipMoodle(), ZipResources()).done(function(){
            downloadZips();
        });
    }
    else{
        setTimeout(finishModifyFiles, 1000);
    }
}

//Modify the Files
function startModifyFiles(){
    BackUpBase(); // STEPS_PERFORMED++;
    paramsCourse(); // STEPS_PERFORMED++;
    descriptionCourse(); // STEPS_PERFORMED++;
    
    $(document).ajaxStop(function () { // Wait to do all the modifications in the document
        if(STEPS_PERFORMED == 3 && !parsing[0]){
            parsing[0] = true;
            BackUpCourse(); // STEPS_PERFORMED++;
        }
        
        if(STEPS_PERFORMED == 4 && !parsing[1]){
            parsing[1] = true;
            BackUpSections(sections, 1); // STEPS_PERFORMED++;
        }
        if(STEPS_PERFORMED == 5 && !parsing[2]){
            parsing[2] = true;
            //Take resources from edCrumbleObj
            getResources(edCrumbleObj['resourcesList'], 1);//setTimeout(getResources.bind(null, edCrumbleObj['resourcesList'], 1), 1000); // STEPS_PERFORMED++;
        }
        if(STEPS_PERFORMED == 6 && !parsing[3]){
            parsing[3] = true;
            backUpSettings(0);//setTimeout(backUpSettings.bind(null, 0), 5000); // STEPS_PERFORMED++;
            updateSequenceSections(0);//setTimeout(updateSequenceSections.bind(null, 0), 5000); // STEPS_PERFORMED++;
            finishModifyFiles();
        }
    });
}

function clearVariables(){
    sections = [];
    dirSections = [];
    sequenceActivities = undefined;
    settings = undefined;
    activitiesArray = []; 
    STEPS_PERFORMED = 0;
    parsing = [false,false,false,false];

    startID = 5;
    moduleID = 25;
    contextID = 66;
}

// Start Moodle Parsing
function sendEdcrumbleInfo(){
    //Clear variables
    clearVariables();

    //Create MoodleBase in Server
    timeStartParse = new Date().getTime()
    nameDirMoodle = edCrumbleObj["designTitle"] + STRING_MARK + timeStartParse.toString();
    nameDirResources = edCrumbleObj["designTitle"] + STRING_MARK + "Resources" + STRING_MARK + timeStartParse.toString();
    backUpFile = nameDirMoodle + '/moodle_backup.xml';

    //Take the sections for the file (weeks)
    var date = new Date(edCrumbleObj['startDate']);
    getSections(date);

    $.when(createNewMoodle(nameDirMoodle, nameDirResources)).done(function(){
        startModifyFiles();
    });
}


//AJAX functions. Send orders to the server

//POST
function createNewMoodle(fileM,fileR){
    return $.ajax({
        url : url,
        type: 'post',
        data : {
            filename : fileM,
            resources : fileR,
            action : 'newMoodle',
        }
    });
}

function createActivity(actName, dir){
    return $.ajax({
        url : url,
        type: 'post',
        data : {
            filename : dir, //dir
            action : 'newActivity',
            nameActivity : actName //Activity name
        }
    });
}

function createResources(name, content){
    return $.ajax({
        url : url,
        type: 'post',
        data : {
            filename : nameDirResources + "/" + name, //dir
            action : 'newResource',
            content : content //Activity name
        }
    });
}

function ModifyParam(file, param, info){
    return $.ajax({
        url : url,
        type: 'post',
        data : {
            filename : file, //file
            action : 'change',
            parameter : param, // Line to edit
            content : info
        }
    });
}

function ZipMoodle(){
    return $.ajax({
        url : url,
        type: 'post',
        data : {
            filename : nameDirMoodle,
            action : 'Zip',
        }
    });
}

function ZipResources(){
    return $.ajax({
        url : url,
        type: 'post',
        data : {
            filename : nameDirResources,
            action : 'Zip',
        }
    });
}


//GET
function DownloadFileResources(){
    return $.ajax({
        url : "phpDownloadFile.php",
        type: 'get',
        data : {
            filename : nameDirResources+".zip",
            action : 'Download_Zip',
        },
        xhrFields: {
            responseType: 'blob'
        },
        success: function (data) {
            var a = document.createElement('a');
            var url = window.URL.createObjectURL(data);
            a.href = url;
            a.download = nameDirResources+".zip";
            document.body.append(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
        }
    });
}

function DownloadFileMoodle(){
    return $.ajax({
        url : "phpDownloadFile.php",
        type: 'get',
        data : {
            filename : nameDirMoodle+".zip",
            action : 'Download_Zip',
        },
        xhrFields: {
            responseType: 'blob'
        },
        success: function (data) {
            var a = document.createElement('a');
            var url = window.URL.createObjectURL(data);
            a.href = url;
            a.download = nameDirMoodle+".zip";
            document.body.append(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
        }

    });
}
